var connection = require('../mysql/connection');

function Catalogo()
{
}

(function () {
    this.list = function (res) {
        connection.acquire(function (err, con) {
            con.query('SELECT cp.id_catalogo, c.nombre, cp.id_producto,p.nombre FROM catalogo_x_producto cp INNER JOIN catalogo c ON cp.id_catalogo = c.id_catalogo INNER JOIN producto p ON p.id_producto=cp.id_producto', function (err, result) {
                con.release();
                res.send(result);
            });
        });
    };

    this.get = function (id, res) {
        connection.acquire(function (err, con) {
            con.query('SELECT cp.id_catalogo, c.nombre, cp.id_producto,p.nombre FROM catalogo_x_producto cp INNER JOIN catalogo c ON cp.id_catalogo = c.id_catalogo INNER JOIN producto p ON p.id_producto=cp.id_producto WHERE cp.id_catalogo = ?', id, function (err, result) {
                con.release();
                res.send(result);
            });
        });
    };

    this.create = function (Catalogo, res) {
        connection.acquire(function (err, con) {
        	con.query('INSERT INTO catalogo_x_producto SET ?', [Catalogo], function (err, result) {
                con.release();
                console.log(Catalogo);
                if (err) {
                    res.send({ status: 1, message: 'Error al asociar el producto en el catalogo', error: err });
                } else {
                    res.send({ status: 0, message: 'Producto asociado correctamente al catalogo' });
                }
            });
        });
    };


    this.update = function (Catalogo, res) {
        connection.acquire(function (err, con) {
        	con.query('UPDATE catalogo_x_producto SET id_catalogo= ?, id_producto = ? WHERE id_producto = ?', [Catalogo.nombre, Catalogo.descripcion,Catalogo.id_marca], function (err, result) {
                con.release();
                if (err) {
                    res.send({ status: 1, message: 'Error al actualizar el registro', error: err });
                } else {
                    res.send({ status: 0, message: 'Registro actualizado satisfactoriamente' });
                }
            });
        });
    };

    this.delete = function (id, res) {
        connection.acquire(function (err, con) {
            con.query('DELETE FROM catalogo_x_producto WHERE id_producto = ?', [id], function (err, result) {
                con.release();
                if (err) {
                    res.send({ status: 1, message: 'Error al eliminar el producto del catalogo', error: err });
                } else {
                    res.send({ status: 0, message: 'Producto eliminado éxitosamente del catalogo' });
                }
            });
        });
    };

    
}).call(Catalogo.prototype);

module.exports = new Catalogo();